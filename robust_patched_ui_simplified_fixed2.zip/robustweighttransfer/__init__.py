# This file is part of Robust Weight Transfer for Blender.
#
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

bl_info = {
    "name": "Robust Weight Transfer",
    "version": (1, 1, 8),
    "blender": (3, 1, 0),
    "location": "View3D > Sidebar > SENT Tab",
    "category": "Object",
}

import sys
import os
import sysconfig
import site

import bpy
import bmesh
import numpy as np
import math
import importlib
import subprocess
import bpy.utils.previews

libs_path = os.path.join(os.path.dirname(__file__), 'deps')
scheme = sysconfig.get_preferred_scheme("user")
user_site = sysconfig.get_paths(scheme, vars={"userbase": libs_path})["purelib"]
site.addsitedir(user_site)

DEPENDENCIES = ["robust_laplacian", "igl", "scipy"]
missing_deps = []
for module in DEPENDENCIES:
    try:
        importlib.import_module(module)
    except ImportError:
        if module == "igl":
            missing_deps.append("libigl==2.5.1")
        else:
            missing_deps.append(module)

installed_deps = False

print(missing_deps)

if not missing_deps:
    import igl
    from . import util
    from . import weighttransfer as _rwt_weighttransfer

    # Hot-reload safety: Blender often reloads only __init__.py, leaving
    # previously imported submodules (util/weighttransfer) stale. This
    # guarantees new functions/signatures become visible after reinstall.
    if __name__ + '.util' in sys.modules:
        importlib.reload(sys.modules[__name__ + '.util'])
    if __name__ + '.weighttransfer' in sys.modules:
        importlib.reload(sys.modules[__name__ + '.weighttransfer'])

    # Re-bind to the (possibly) reloaded module symbols.
    from .weighttransfer import find_matches_closest_surface, inpaint, limit_mask, smooth_weigths


"""Add-on operators and UI.

This patched version keeps the core transfer logic intact, but simplifies the
Vertex Mapping UI as requested:

- Rejected (Distance): island-level (connected-component) selection.
- Rejected (Normal): full-mesh selection of vertices that passed distance but
  were rejected by normal, excluding successful matches and a fixed 1-ring.
- Removes the old "Rejected Loose Parts" and the previous rejected-normal UI.

All rejected selection operators recompute mapping once per click (no cache).
"""


class RobustWeightTransfer(bpy.types.Operator):
    """Transfer Skin Weights Robust"""
    bl_idname = "object.skin_weight_transfer"
    bl_label = "Robust Weight Transfer"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        # Only available in Mesh Object/Edit contexts (disabled for Armature Edit/Pose)
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return False
        
        scene_settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        if not scene_settings.source_object: return False
        if not scene_settings.apply_to_selected and scene_settings.source_object == context.active_object: return False
        if scene_settings.group_selection == 'DEFORM_POSE_BONES':
            armature_mods = [mod for mod in scene_settings.source_object.modifiers if mod.type == "ARMATURE"]
            if len(armature_mods) != 1: return False # no armature modifier or more than one
            if not armature_mods[0].object: return False

            
        objs = lambda x: [obj for obj in x if obj != scene_settings.source_object and isinstance(obj.data, bpy.types.Mesh)]
        if scene_settings.apply_to_selected:
            target_objs = objs(context.selected_objects)
        else:
            if not context.object: return False
            target_objs = objs([context.object])
            
        if len(target_objs) == 0: return False
        if scene_settings.use_deformed_target and any(util.has_modifier(obj, *util.TOPOLOGY_MODS) for obj in target_objs): return False
        
        if not scene_settings.apply_to_selected:
            obj = target_objs[0]
            object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings
            mask = object_settings.vertex_group
            if len(mask) > 0 and mask not in obj.vertex_groups: return False
            inpaint = object_settings.inpaint_group
            if len(inpaint) > 0 and  inpaint not in obj.vertex_groups: return False
        return True


    def execute(self, context: bpy.types.Context):
        scene_settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        
        source_obj: bpy.types.Object = scene_settings.source_object
        if source_obj.type != 'MESH':
            self.report({'ERROR'}, f'Source object {source_obj.name} is not a mesh')
            return {'CANCELLED'}
    
        if scene_settings.apply_to_selected:
            target_objs = [obj for obj in context.selected_objects if obj != source_obj and isinstance(obj.data, bpy.types.Mesh)]
        else:
            target_objs = [context.object]
        
        depsgraph = context.evaluated_depsgraph_get()
        if scene_settings.use_deformed_source:
            source_obj = source_obj.evaluated_get(depsgraph)
        
        weights_all = [] # (num_objs, (num_vertices, num_weights))
        source_verts, source_triangles, source_normals = util.get_obj_arrs_world(source_obj)
        deform_only = scene_settings.group_selection == 'DEFORM_POSE_BONES'
        is_deform = [util.is_vertex_group_deform_bone(source_obj, g.name) for g in source_obj.vertex_groups]
        source_weights = util.get_groups_arr(source_obj, is_deform if deform_only else None) # (num_verts, )
        for obj in target_objs:
            object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings
            verts, triangles, normals = util.get_obj_arrs_world(obj.evaluated_get(depsgraph) if scene_settings.use_deformed_target else obj)
            matched_verts, weights, sqrD, deg_angles, pass_dist, pass_norm = find_matches_closest_surface(
                source_verts,
                source_triangles,
                source_normals,
                verts,
                normals,
                source_weights,
                scene_settings.max_distance**2,
                math.degrees(scene_settings.max_normal_angle_difference),
                scene_settings.flip_vertex_normal,
                return_diagnostics=True,
            )

            if not scene_settings.apply_to_selected:
                if util.is_group_valid(obj.vertex_groups, object_settings.inpaint_group):
                    inpaint_mask = util.get_group_arr(obj, object_settings.inpaint_group)
                    inpaint_mask_bin = inpaint_mask > object_settings.inpaint_threshold
                    if object_settings.inpaint_group_invert:
                        inpaint_mask_bin = ~inpaint_mask_bin
                    # Exclude intentionally from transfer/match diagnostics
                    matched_verts = np.logical_and(matched_verts, ~inpaint_mask_bin)
            
            
            if scene_settings.draw_matched:
                res = util.draw_debug_vertex_colors(obj, matched_verts)
                if not res:
                    self.report({'ERROR'}, f'{obj.name} has too many vertex colors. Delete one or deactive Visualize Rejected Weights.')
                    return {'CANCELLED'}

                
            result, weights = inpaint(verts, triangles, weights, matched_verts, scene_settings.inpaint_mode == 'POINT')
            if not result:
                self.report({'ERROR'}, f'Failed weight inpainting on {obj.name}: This usually happens on loose parts, where vertices are not finding a match on the source mesh. Use Rejected (Distance) to locate fully-unmatched islands and fix/remove them.')
                return {'CANCELLED'}
            
            adj_mat = util.get_mesh_adjacency_matrix_sparse(obj.data, include_self=True)
            if scene_settings.smoothing_enable:
                adj_list = util.get_mesh_adjacency_list(obj.data)
                weights = smooth_weigths(verts, weights, matched_verts, adj_mat, adj_list, scene_settings.smoothing_repeat, scene_settings.smoothing_factor, scene_settings.max_distance)
            
            if scene_settings.enforce_four_bone_limit:
                weights[weights <= 0.0001] = 0
                mask = limit_mask(weights, adj_mat, limit_num=scene_settings.num_limit_groups)
                weights = (1 - mask) * weights
                weights[weights <= 0.0001] = 0
            
            weights_all.append(weights)

            # No per-object mapping cache is maintained. Selection helpers recompute
            # diagnostics on demand to avoid stale-cache bugs.
        for obj, weights in zip(target_objs, weights_all):
            target_obj = obj
            source_vertex_groups = source_obj.vertex_groups
            weight_counts = np.count_nonzero(weights, axis=0)
            for group, w_count in zip(source_vertex_groups, weight_counts):
                if w_count > 0:
                    if group.name not in obj.vertex_groups:
                        obj.vertex_groups.new(name=group.name)
            
            is_deform = [util.is_vertex_group_deform_bone(source_obj, g.name) for g in source_vertex_groups]
            
            # Selection scope replaces transfer mask:
            # - Edit Mode: operate only on selected vertices (if none selected -> all vertices)
            # - Object Mode: operate on all vertices
            scope_indices = None
            if obj.mode == 'EDIT':
                scope_indices = util.get_selected_vert_indices(obj)
                if len(scope_indices) == 0:
                    self.report({'WARNING'}, 'Edit Mode requires at least one selected vertex')
                    return {'CANCELLED'}

            for i, w in enumerate(weights.T):
                w_count = weight_counts[i]
                if w_count == 0: continue
                
                source_group = source_vertex_groups[i]
                target_group = obj.vertex_groups[source_group.name]
                
                if target_group.lock_weight:
                    continue
                if deform_only and not is_deform[i]:
                    continue
                # Write weights (BMesh in Edit Mode, vertex group ops otherwise)
                # Safety: never write back to a non-target object
                assert obj is target_obj
                util.set_group_weights(obj, target_group.name, w, threshold=0.00001, indices=scope_indices)   
        
        if scene_settings.draw_matched:
            if isinstance(context.space_data, bpy.types.SpaceView3D):
                view: bpy.types.SpaceView3D = context.space_data
                view.shading.type = 'SOLID'
                view.shading.color_type = 'VERTEX'
        if scene_settings.apply_to_selected:
            self.report({'INFO'}, f'Weights transfered from {source_obj.name} to selected objects')
        else:
            self.report({'INFO'}, f'Weights transfered from {source_obj.name} to {context.object.name}')
        return {'FINISHED'}
    

class SelectRejectedByDistance(bpy.types.Operator):
    """Select vertices that fail the distance gate (cached)"""
    bl_idname = "object.rwt_select_rejected_by_distance"
    bl_label = "Rejected (Distance)"
    bl_description = "Select/deselect vertices that did not find a closest-surface match within Max Distance (recomputes mapping once; does not write weights)"
    bl_options = {'REGISTER', 'UNDO'}

    deselect: bpy.props.BoolProperty(name="Deselect", default=False)

    @classmethod
    def poll(cls, context):
        if context.mode != 'EDIT_MESH':
            return False
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return False
        settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        if not settings.source_object or settings.source_object == obj:
            return False
        if settings.use_deformed_target and util.has_modifier(obj, *util.TOPOLOGY_MODS):
            return False
        return True

    def execute(self, context):
        settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        obj = context.active_object
        object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings

        depsgraph = context.evaluated_depsgraph_get()
        src = settings.source_object

        source_obj = src.evaluated_get(depsgraph) if settings.use_deformed_source else src
        target_obj = obj.evaluated_get(depsgraph) if settings.use_deformed_target else obj

        source_verts, source_triangles, source_normals = util.get_obj_arrs_world(source_obj)
        verts, triangles, normals = util.get_obj_arrs_world(target_obj)

        deform_only = settings.group_selection == 'DEFORM_POSE_BONES'
        is_deform = [g.name in src.vertex_groups for g in src.vertex_groups]  # placeholder; kept for compat
        source_weights = util.get_groups_arr(source_obj, is_deform if deform_only else None)

        matched, _w2, sqrD, deg_angles, pass_dist, pass_norm = find_matches_closest_surface(
            source_verts,
            source_triangles,
            source_normals,
            verts,
            normals,
            source_weights,
            settings.max_distance ** 2,
            math.degrees(settings.max_normal_angle_difference),
            settings.flip_vertex_normal,
            return_diagnostics=True,
        )

        # Island-level semantics (former "Rejected Loose Parts"): select entire connected
        # components that have ZERO vertices passing the distance gate.
        num_conn, conn, _num_vertices = igl.connected_components(igl.adjacency_matrix(triangles))
        conns = [np.where(conn == i)[0] for i in range(num_conn)]
        pass_per_island = [int(np.count_nonzero(pass_dist[c])) for c in conns]
        zero_pass_islands = [i for i, c in enumerate(pass_per_island) if c == 0]

        rejected_by_distance = np.zeros(verts.shape[0], dtype=bool)
        for i in zero_pass_islands:
            rejected_by_distance[conns[i]] = True

        util.select_mask_vertices(obj, rejected_by_distance, action=('deselect' if self.deselect else 'select'))
        self.report({'INFO'}, f"{'Deselected' if self.deselect else 'Selected'} {int(np.count_nonzero(rejected_by_distance))} vertices (distance: zero-pass islands).")
        return {'FINISHED'}


class SelectRejectedByNormal(bpy.types.Operator):
    """Select vertices that pass distance but fail normal gate (cached)"""
    bl_idname = "object.rwt_select_rejected_by_normal"
    bl_label = "Rejected (Normal)"
    bl_description = "Select/deselect vertices that passed Max Distance but were rejected by Max Normal Difference (recomputes mapping once; does not write weights)"
    bl_options = {'REGISTER', 'UNDO'}

    deselect: bpy.props.BoolProperty(name="Deselect", default=False)

    @classmethod
    def poll(cls, context):
        if context.mode != 'EDIT_MESH':
            return False
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return False
        settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        if not settings.source_object or settings.source_object == obj:
            return False
        if settings.use_deformed_target and util.has_modifier(obj, *util.TOPOLOGY_MODS):
            return False
        return True

    def execute(self, context):
        settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        obj = context.active_object
        object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings

        depsgraph = context.evaluated_depsgraph_get()
        src = settings.source_object

        source_obj = src.evaluated_get(depsgraph) if settings.use_deformed_source else src
        target_obj = obj.evaluated_get(depsgraph) if settings.use_deformed_target else obj

        source_verts, source_triangles, source_normals = util.get_obj_arrs_world(source_obj)
        verts, triangles, normals = util.get_obj_arrs_world(target_obj)

        deform_only = settings.group_selection == 'DEFORM_POSE_BONES'
        is_deform = [g.name in src.vertex_groups for g in src.vertex_groups]  # placeholder; kept for compat
        source_weights = util.get_groups_arr(source_obj, is_deform if deform_only else None)

        matched, _w2, sqrD, deg_angles, pass_dist, pass_norm = find_matches_closest_surface(
            source_verts,
            source_triangles,
            source_normals,
            verts,
            normals,
            source_weights,
            settings.max_distance ** 2,
            math.degrees(settings.max_normal_angle_difference),
            settings.flip_vertex_normal,
            return_diagnostics=True,
        )

        rejected = np.logical_and(pass_dist, np.logical_not(pass_norm))

        # UI spec: "Rejected by Normal" selects verts that passed distance but failed
        # normal, excluding successful matches PLUS one topological edge ring around them.
        success_mask = matched.astype(bool)
        expanded = util.expand_mask_rings(obj.data, success_mask, 1)
        rejected = np.logical_and(rejected, np.logical_not(expanded))

        util.select_mask_vertices(obj, rejected, action=('deselect' if self.deselect else 'select'))
        self.report({'INFO'}, f"{'Deselected' if self.deselect else 'Selected'} {int(np.count_nonzero(rejected))} vertices (normal gate).")
        return {'FINISHED'}

    
class Inpaint(bpy.types.Operator):
    """Inpaint"""
    bl_idname = "object.rwt_inpaint"
    bl_label = "Inpaint"
    bl_description = "Inpaint active object using the inpaint mask"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        # Only available in Mesh Object/Edit contexts (disabled for Armature Edit/Pose)
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return False
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return False

        # When an object is deleted or the context is in a transient state,
        # `active_object` can be None; also a non-mesh can be active.
        # Guard before accessing custom properties.
        if not hasattr(obj, "robust_weight_transfer_settings"):
            return False

        scene_settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings

        if len(object_settings.inpaint_group) == 0 or object_settings.inpaint_group not in obj.vertex_groups:
            return False

        if scene_settings.use_deformed_target and util.has_modifier(obj, *util.TOPOLOGY_MODS):
            return False
        return True

    def execute(self, context):
        scene_settings: SceneSettingsGroup = context.scene.robust_weight_transfer_settings
        obj = context.active_object
        object_settings: ObjectSettingsGroup = obj.robust_weight_transfer_settings
        

        scope_indices = None
        if obj.mode == 'EDIT':
            scope_indices = util.get_selected_vert_indices(obj)
            if len(scope_indices) == 0:
                self.report({'WARNING'}, 'Edit Mode requires at least one selected vertex')
                return {'CANCELLED'}
        depsgraph = context.evaluated_depsgraph_get()
        verts, triangles, normals = util.get_obj_arrs_world(obj.evaluated_get(depsgraph) if scene_settings.use_deformed_target else obj)
        is_deform = [util.is_vertex_group_deform_bone(obj, g.name) for g in obj.vertex_groups]
        weights = util.get_groups_arr(obj, is_deform)

        inpaint_mask = util.get_group_arr(obj, object_settings.inpaint_group)
        inpaint_mask_bin = inpaint_mask > object_settings.inpaint_threshold
        result, weights = inpaint(verts, triangles, weights, ~inpaint_mask_bin, scene_settings.inpaint_mode == 'POINT')
        if not result:
            self.report({'ERROR'}, f'Failed weight inpainting on {obj.name}: This usually happens on disconnected/loose parts that do not find any match on the source mesh. Use the Vertex Mapping > Rejected (Distance) selection tool to locate them.')
            return {'CANCELLED'}

        for i, w in enumerate(weights.T):
            group = obj.vertex_groups[i]
            if group.lock_weight: continue
            
            if not is_deform[i]: continue
            
            w_count = np.count_nonzero(w)
            if w_count == 0: continue

            util.set_group_weights(obj, group.name, w, threshold=0.00001, indices=scope_indices)  
        self.report({'INFO'}, f'Weights inpainted.')
        return {'FINISHED'}
        

class ObjectSettingsGroup(bpy.types.PropertyGroup):
    vertex_group: bpy.props.StringProperty(name='Mask Vertex Group')
    vertex_group_invert: bpy.props.BoolProperty(name='Invert')
    inpaint_group: bpy.props.StringProperty(name='Inpaint Vertex Group')
    inpaint_group_invert: bpy.props.BoolProperty(name='Invert Inpaint')
    inpaint_threshold: bpy.props.FloatProperty(name='Inpaint Binary Threshold', default=0.5, min=0, max=1)
    
def update_enforce_four_bone_limit(self, context):
    """Ensure the correct group selection and enforce constraints."""
    if self.enforce_four_bone_limit:
        self.group_selection = 'DEFORM_POSE_BONES'
    
class SceneSettingsGroup(bpy.types.PropertyGroup):
    source_object: bpy.props.PointerProperty(name='Source', type=bpy.types.Object, poll=lambda self, obj: obj.type == 'MESH')
    shape_key_mix: bpy.props.BoolProperty(name='Use Shape Key Mix', description='Uses the Shape of the Shape Key Mix to transfer the weights', default=True)
    max_distance: bpy.props.FloatProperty(
        name='Max Distance',
        description='Maximum allowed distance between source and destination vertex',
        default=0.05,
        min=0,
        unit='LENGTH',
        subtype='DISTANCE')
    max_normal_angle_difference: bpy.props.FloatProperty(
        name='Max Normal Difference',
        description='Maximum allowed vertex normal difference between source and destination vertex',
        default=math.radians(30),
        min=0,
        max=math.pi,
        precision=3,
        step=100,
        unit='ROTATION',
        subtype='ANGLE')

    flip_vertex_normal: bpy.props.BoolProperty(
        name='Flip Vertex Normal',
        description='Allow vertex normal flipped at 180° between source and destination vertex',
        default=True)
    smoothing_factor: bpy.props.FloatProperty(
        name='Smoothing factor',
        description='Smoothing factor used in the smoothing pass.',
        default=0.2,
        min=0,
        max=1,
        step=10)
    smoothing_repeat: bpy.props.IntProperty(
        name='Smoothing repeat',
        description='Amount of iterations of smoothing used in the smoothing pass',
        default=4,
        min=0)
    apply_to_selected: bpy.props.BoolProperty(
        name='Apply to all Selected Objects',
        description='Weight transfers the from the source object to all selected objects')
    use_modifier: bpy.props.BoolProperty(name='Use Modifier', description='Uses the Shape resulting from the source objects modifier stack', default=True)
    use_deformed_source: bpy.props.BoolProperty(name='Use Deformed Source', description='Uses the Shape resulting from the source object\'s modifier stack and shape keys', default=True)
    use_deformed_target: bpy.props.BoolProperty(name='Use Deformed Target', description='Uses the Shape resulting from the target object\'s modifier stack and shape keys', default=True)
    draw_matched: bpy.props.BoolProperty(
        name='Visualize Rejected Weights',
        description='Draws rejected weights as a pink to the vertex color layer "RBT Matched". After each transfer it will set the vertex color layer to active and change the Viewport Shading to Solid, with Color set to Attribute')
    enforce_four_bone_limit: bpy.props.BoolProperty(
        name='Limit Groups per Vertex',
        description='Limit a vertex to being influenced to a specific amount of groups. This is useful when a mesh will be exported to game engines like Unity, that normally only support 4 bones per vertex',
        default=True,
        update=update_enforce_four_bone_limit)
    group_selection: bpy.props.EnumProperty(
        name='Group Type',
        description='Select what subset of Vertex Group\'s should be transferred',
        items=[
            ('ALL_GROUPS', 'All Groups', 'Transfer all groups'),
            ('DEFORM_POSE_BONES', 'Deform Pose Bones', 'Only transfer deform pose bones, used by the Armature')
        ],
        default='DEFORM_POSE_BONES')
    dilation_repeat: bpy.props.IntProperty(
        name='Dilation repeat',
        description='Amount of iterations used to smooth the weight remove mask, that is used to limit the bone influence per vertex to 4',
        default=4,
        min=0)
    inpaint_mode: bpy.props.EnumProperty(
        name='Mode',
        description='Choose the Inpaint Mode',
        items=[
            ('POINT', 'Point', 'Object is remeshed internally. Weights can "flow" outside a mesh/loose part and more robust' ),
            ('SURFACE', 'Surface', 'Mesh is used as is. Weights "flow" only inside a mesh/loose part. More likely to fail compared to "Point"')
        ],
        default='POINT')
    smoothing_enable: bpy.props.BoolProperty(
        name='Enable Smoothing',
        description='Smooths weights in the area where weights got inpainted',
        default=False)
    smooth_limit_debug: bpy.props.BoolProperty(
        name='Limited vertices to Vertex Group',
        description='Visualize the vertices that got limited by writing to the "Limited" vertex group',
        default=False)
    num_limit_groups: bpy.props.IntProperty(
        name="Max groups per vertex",
        description="Amount of groups a vertex should be limited to. For VRChat/Unity keep it at 4.",
        min=1,
        default=4
    )


class RobustWeightTransferPanel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Robust Weight Transfer"
    bl_idname = "OBJECT_PT_robust_weight_transfer_panel"
    bl_space_type = 'VIEW_3D'   # Defines the space type where the panel is located
    bl_region_type = 'UI'       # Specifies that the panel is drawn in the UI region
    bl_category = 'SENT'      # The name of the tab the panel will be in
    bl_options = set()

    def draw(self, context): 
        layout = self.layout

        if missing_deps:
            box = layout.box()
            col = box.column()
            global installed_deps
            if installed_deps:
                col.label(text="Dependencies installed!", icon='INFO')
                col.label(text="Restart Blender!", icon='ERROR')
                installed_deps = True
                return
            
            col.label(text="Blender will be unreactive while installing")
            col.operator("wm.install_rwt_dependencies", icon='IMPORT')
            col.label(text="This might take a few minutes", icon='INFO')
            return

        active_obj = context.object
        if not context.object:
            layout.label(text='No active object selected.')
            return
        
        props = active_obj.robust_weight_transfer_settings
        settings = context.scene.robust_weight_transfer_settings
        
        # Object field for source
        row = layout.row(align=True)
        row.prop(settings, "source_object")
        row.prop(settings, "use_deformed_source",toggle=True, text="", icon='SHAPEKEY_DATA')
        row.prop(settings, "use_deformed_source",toggle=True, text="", icon='MODIFIER')
        
        # Selection scope (replaces transfer mask)
        box = layout.box()
        col = box.column(align=True)
        col.label(text='Selection Scope')
        col.label(text='Edit Mode: only selected vertices are modified (must select >= 1)')
        col.label(text='Object Mode: all vertices are modified')
        
        objs = lambda x: [obj for obj in x if obj != settings.source_object and isinstance(obj.data, bpy.types.Mesh)]
        if settings.apply_to_selected:
            target_objs = objs(context.selected_objects)
        else:
            target_objs = objs([context.object])
        if (len(target_objs) > 0
                and settings.use_deformed_target
                and any(util.has_modifier(obj, *util.TOPOLOGY_MODS) for obj in target_objs)):
            objs_str = ', '.join(obj.name for obj in target_objs)
            col = layout.column(align=True)
            col.label(text=f'Error: {objs_str}', icon='ERROR')
            col.label(text='  Topology altering Modifier!', icon='SHAPEKEY_DATA')
            col.label(text='  Deactivate Use Deformed Target or apply/delete modifier.', icon='MODIFIER')
            
        source_obj = settings.source_object
        if source_obj:
            armature_mods = [mod for mod in source_obj.modifiers if mod.type == "ARMATURE"]
            if len(armature_mods) == 0:
                col = layout.column(align=True)
                col.label(text=f'Subset is set to Deform Pose Bones,', icon='ERROR')
                col.label(text=f'but {source_obj.name} has no Armature Modifier')
            elif len(armature_mods) == 1:
                if not armature_mods[0].object:
                    col = layout.column(align=True)
                    col.label(text=f'Subset is set to Deform Pose Bones,', icon='ERROR')
                    col.label(text=f'but {source_obj.name} has an empty Armature Modifier object')
            else:
                col = layout.column(align=True)
                col.label(text=f'Subset is set to Deform Pose Bones,', icon='ERROR')
                col.label(text=f'but {source_obj.name} has multiple Armature Modifiers')
            
        row = layout.row(align=True)
        row.prop(settings, 'apply_to_selected', text='', icon='RESTRICT_SELECT_OFF')
        row.operator("object.skin_weight_transfer", text="Transfer Weights")
        row.prop(settings, "use_deformed_target",toggle=True, text="", icon='SHAPEKEY_DATA')
        row.prop(settings, "use_deformed_target",toggle=True, text="", icon='MODIFIER')
        
        layout.separator(factor=1)
        
        col = layout.column()
        col.label(text='Inpaint Mask')
        row = col.row(align=True)
        row.prop_search(props, "inpaint_group", active_obj, 'vertex_groups', text='')
        row.prop(props , "inpaint_group_invert",text="", toggle=True, icon='ARROW_LEFTRIGHT')
        row.prop(props, 'inpaint_threshold', text="")
        row.enabled = not settings.apply_to_selected

        
class SettingsPanel(bpy.types.Panel):
    bl_idname = 'OBJECT_PT_robust_weight_transfer_settings_panel'
    bl_label = 'Settings'
    bl_space_type = 'VIEW_3D'   # Defines the space type where the panel is located
    bl_region_type = 'UI'       # Specifies that the panel is drawn in the UI region
    bl_category = 'SENT'      # The name of the tab the panel will be in
    bl_parent_id = 'OBJECT_PT_robust_weight_transfer_panel'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.robust_weight_transfer_settings
        layout.operator('object.rbt_reset_scene_settings', icon='LOOP_BACK', text='Reset to Defaults')
        layout.prop(settings, 'inpaint_mode')
        layout.prop(settings, 'draw_matched')
        row = layout.row()
        row.enabled = not settings.enforce_four_bone_limit
        row.prop(settings, 'group_selection', text='Subset')


class VertexMappingPanel(bpy.types.Panel):
    bl_label = "Vertex Mapping"
    bl_idname = "OBJECT_PT_vertex_mapping"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SENT'
    bl_parent_id = 'OBJECT_PT_robust_weight_transfer_settings_panel'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.robust_weight_transfer_settings
        col = layout.column(align=True)
        col.prop(settings, "max_distance")
        row = col.row(align=True)
        row.operator("object.rwt_select_rejected_by_distance", text="Select Rejected (Islands)", icon='RESTRICT_SELECT_OFF').deselect = False
        row.operator("object.rwt_select_rejected_by_distance", text="Deselect", icon='RESTRICT_SELECT_ON').deselect = True

        col.separator(factor=0.5)
        col.prop(settings, "max_normal_angle_difference")
        row = col.row(align=True)
        row.operator("object.rwt_select_rejected_by_normal", text="Select Rejected", icon='RESTRICT_SELECT_OFF').deselect = False
        row.operator("object.rwt_select_rejected_by_normal", text="Deselect", icon='RESTRICT_SELECT_ON').deselect = True

        col.separator(factor=0.5)
        col.prop(settings, "flip_vertex_normal", text='Allow Flipped Vertex Normals')


class SmoothingPanel(bpy.types.Panel):
    bl_label = "Smoothing"
    bl_idname = "OBJECT_PT_smoothing"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SENT'
    bl_parent_id = 'OBJECT_PT_robust_weight_transfer_settings_panel'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.robust_weight_transfer_settings
        layout.enabled = settings.smoothing_enable
        layout.prop(settings, 'smoothing_repeat')
        layout.prop(settings, 'smoothing_factor')
        
    def draw_header(self, context: bpy.types.Context):
        settings = context.scene.robust_weight_transfer_settings
        col = self.layout.column(align=True)
        col.prop(settings, 'smoothing_enable', text='')

class LimitGroupsPanel(bpy.types.Panel):
    bl_label = "Limit Vertex Groups"
    bl_idname = "OBJECT_PT_limit_groups"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SENT'
    bl_parent_id = 'OBJECT_PT_robust_weight_transfer_settings_panel'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.robust_weight_transfer_settings
        layout.enabled = settings.enforce_four_bone_limit
        layout.prop(settings, 'num_limit_groups')
        
    def draw_header(self, context: bpy.types.Context):
        settings = context.scene.robust_weight_transfer_settings
        col = self.layout.column(align=True)
        col.prop(settings, 'enforce_four_bone_limit', text='')


class ResetSceneSettings(bpy.types.Operator):
    """Reset all settings to their default values"""
    bl_idname = "object.rbt_reset_scene_settings"
    bl_label = "Reset Robust Weight Transfer to Default Settings"

    def execute(self, context):
        settings = context.scene.robust_weight_transfer_settings
        for prop_name, prop in settings.bl_rna.properties.items():
            if prop.is_readonly or prop_name in {'rna_type', 'name'}:
                continue
            if hasattr(prop, 'default'):
                setattr(settings, prop_name, prop.default)
            else:
                setattr(settings, prop_name, None)
        return {'FINISHED'}


class ClearRuntimeCache(bpy.types.Operator):
    """Clear in-memory caches used by Robust Weight Transfer.

    This does not modify any meshes; it only drops cached BVH / mapping diagnostics
    so the next run recomputes them."""
    bl_idname = "object.rwt_clear_runtime_cache"
    bl_label = "Clear Runtime Cache"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            util.cache_clear_all()
        except Exception as ex:
            self.report({'WARNING'}, f"Failed to clear cache: {ex}")
            return {'CANCELLED'}
        self.report({'INFO'}, "Runtime cache cleared.")
        return {'FINISHED'}


class UtilitiesPanel(bpy.types.Panel):
    bl_idname = 'OBJECT_PT_robust_weight_utilities_settings_panel'
    bl_label = 'Utilities'
    bl_space_type = 'VIEW_3D'   # Defines the space type where the panel is located
    bl_region_type = 'UI'       # Specifies that the panel is drawn in the UI region
    bl_category = 'SENT'      # The name of the tab the panel will be in
    bl_parent_id = 'OBJECT_PT_robust_weight_transfer_panel'
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        settings = context.scene.robust_weight_transfer_settings
        row = layout.row(align=True)
        row.operator('object.smooth_limit_weights')
        row.prop(settings, 'smooth_limit_debug', text='', icon='GROUP_VERTEX')
        layout.operator('object.rwt_inpaint')
    

class SmoothLimit(bpy.types.Operator):
    """Limit weights of to a specific amount"""
    bl_idname = "object.smooth_limit_weights"
    bl_label = "Smoothed Limit Vertex Groups"
    bl_description = "Limits the amount weights per vertex of the active object"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        # Only available in Mesh Object/Edit contexts (disabled for Armature Edit/Pose)
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return False
        if not context.active_object: return False
        if context.active_object.type != 'MESH': return False
        
        return True
    
    def execute(self, context):
        scene_settings = context.scene.robust_weight_transfer_settings
        obj = context.active_object

        scope_indices = None
        if obj.mode == 'EDIT':
            scope_indices = util.get_selected_vert_indices(obj)
            if len(scope_indices) == 0:
                self.report({'WARNING'}, 'Edit Mode requires at least one selected vertex')
                return {'CANCELLED'}
        is_deform = [util.is_vertex_group_deform_bone(obj, g.name) for g in obj.vertex_groups]
        W = util.get_groups_arr(obj, is_deform)
        adj_mat = util.get_mesh_adjacency_matrix_sparse(obj.data, True)
        mask = limit_mask(W, adj_mat, limit_num=scene_settings.num_limit_groups)
        W = (1 - mask) * W
        util.write_weights(obj, W[:, is_deform], [group.name for i, group in enumerate(obj.vertex_groups, scope_indices=scope_indices) if is_deform[i]], 0.0001)
        if scene_settings.smooth_limit_debug:
            limited = np.max(mask, axis=1)
            util.write_weights(obj, limited[:, np.newaxis], ['Limited'], scope_indices=scope_indices)
        return {'FINISHED'}

class InstallDependencies(bpy.types.Operator):
    """Install missing Python dependencies"""
    bl_idname = "wm.install_rwt_dependencies"
    bl_label = "Install Dependencies"
    
    def execute(self, context):
        python_exe = sys.executable
        print(python_exe)
        try:
            # create a constraints.txt to constrain the dependency install to the numpy version that blender ships with
            constraints_path = os.path.join(os.path.dirname(__file__), "constraints.txt")
            with open(constraints_path, "w") as f:
                f.write(f"numpy=={np.__version__}") 

            # we do a pip user install under a custom user base path
            # makes use of existing installed python packages like numpy, still uses pips dependency resolution and keeps it isolated
            env = os.environ.copy()
            env["PYTHONUSERBASE"] = libs_path
            subprocess.check_call([python_exe, "-m", "pip", "install", "--user", *missing_deps, "--break-system-packages", "-c", constraints_path], env=env)
            self.report({'INFO'}, "Installation successful! Please restart Blender.")
            global installed_deps
            installed_deps = True
            return {'FINISHED'}
        except subprocess.CalledProcessError as e:
            self.report({'ERROR'}, f"Installation failed: {str(e)}")
            return {'CANCELLED'}

def register():
    # bpy.types.VIEW3D_MT_make_links.append(menu_func)
    bpy.utils.register_class(RobustWeightTransfer)
    bpy.utils.register_class(RobustWeightTransferPanel)
    if missing_deps:
        bpy.utils.register_class(InstallDependencies)
    else:
        bpy.utils.register_class(SettingsPanel)
        bpy.utils.register_class(VertexMappingPanel)
        bpy.utils.register_class(LimitGroupsPanel)
        bpy.utils.register_class(SmoothingPanel)
        bpy.utils.register_class(ObjectSettingsGroup)
        bpy.utils.register_class(SceneSettingsGroup)
        bpy.utils.register_class(SelectRejectedByDistance)
        bpy.utils.register_class(SelectRejectedByNormal)
        bpy.utils.register_class(ClearRuntimeCache)
        bpy.utils.register_class(ResetSceneSettings)
        bpy.utils.register_class(UtilitiesPanel)
        bpy.utils.register_class(SmoothLimit)
        bpy.utils.register_class(Inpaint)
        bpy.types.Object.robust_weight_transfer_settings = bpy.props.PointerProperty(type=ObjectSettingsGroup)
        bpy.types.Scene.robust_weight_transfer_settings = bpy.props.PointerProperty(type=SceneSettingsGroup)

def unregister():
    # bpy.types.VIEW3D_MT_make_links.remove(menu_func)
    bpy.utils.unregister_class(RobustWeightTransfer)
    bpy.utils.unregister_class(RobustWeightTransferPanel)
    if missing_deps:
        bpy.utils.unregister_class(InstallDependencies)
    else:
        bpy.utils.unregister_class(SettingsPanel)
        bpy.utils.unregister_class(VertexMappingPanel)
        bpy.utils.unregister_class(LimitGroupsPanel)
        bpy.utils.unregister_class(SmoothingPanel)
        bpy.utils.unregister_class(ObjectSettingsGroup)
        bpy.utils.unregister_class(SceneSettingsGroup)
        bpy.utils.unregister_class(SelectRejectedByDistance)
        bpy.utils.unregister_class(SelectRejectedByNormal)
        bpy.utils.unregister_class(ClearRuntimeCache)
        bpy.utils.unregister_class(ResetSceneSettings)
        bpy.utils.unregister_class(UtilitiesPanel)
        bpy.utils.unregister_class(SmoothLimit)
        bpy.utils.unregister_class(Inpaint)
        del bpy.types.Object.robust_weight_transfer_settings
        del bpy.types.Scene.robust_weight_transfer_settings
if __name__ == "__main__":
    register()